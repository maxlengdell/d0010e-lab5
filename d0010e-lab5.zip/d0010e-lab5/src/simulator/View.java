package simulator;
import java.util.Observable;
/**
*
** @author Shahin Salehi, Max Lengdell , Johan Jirlén, Linus Lindahl Marjavaara
*
*/
import java.util.Observer;

/**
*
* @author Shahin Salehi, Max Lengdell , Johan Jirlén, Linus Lindahl Marjavaara
*General class for View.
*/
@SuppressWarnings("deprecation")
public class View implements Observer {
	
	@Override
	public void update(Observable arg0, Object arg1) {
		// TODO Auto-generated method stub
		
	}

}
